function e(e,t){let n=t instanceof Error?t.message:`unhandled`;console.error(`[error] ${e}`,n)}export{e as t};
//# sourceMappingURL=route-error-BvrwbTEm.js.map