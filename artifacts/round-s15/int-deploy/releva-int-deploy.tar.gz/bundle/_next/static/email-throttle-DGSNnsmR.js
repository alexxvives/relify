import{m as e}from"./headers-egSJat3G.js";import{n as t}from"./db-CmYct9IK.js";import{createHash as n}from"node:crypto";function r(e){return n(`sha256`).update(e.trim().toLowerCase()).digest(`hex`).slice(0,32)}async function i(){try{let t=await e();return t.get(`cf-connecting-ip`)??t.get(`x-forwarded-for`)?.split(`,`)[0]?.trim()??`unknown`}catch{return`unknown`}}async function a(e,n,r,i=!0){try{let i=await t.$queryRaw`
      INSERT INTO "email_throttle" ("key", "count", "window_start") VALUES (${e}, 1, NOW())
      ON CONFLICT ("key") DO UPDATE SET
        "count" = CASE WHEN "email_throttle"."window_start" < NOW() - make_interval(secs => ${r}::double precision) THEN 1 ELSE "email_throttle"."count" + 1 END,
        "window_start" = CASE WHEN "email_throttle"."window_start" < NOW() - make_interval(secs => ${r}::double precision) THEN NOW() ELSE "email_throttle"."window_start" END
      RETURNING "count"`;return Number(i[0]?.count??1)<=n}catch{return i?(console.warn(`[throttle] counter unavailable; allowing`),!0):(console.warn(`[throttle] counter unavailable; denying`),!1)}}export{a as n,r,i as t};
//# sourceMappingURL=email-throttle-DGSNnsmR.js.map