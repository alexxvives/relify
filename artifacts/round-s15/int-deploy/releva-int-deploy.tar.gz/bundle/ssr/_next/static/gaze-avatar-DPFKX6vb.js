function e(e){let t=0;for(let n=0;n<e.length;n+=1)t=t*33+e.charCodeAt(n)>>>0;return t}function t(t){let n=e(t.replace(/[^a-zA-Z0-9]/g,``).slice(0,32)||`relify`),r=`#1c2740`,i=`#0f6e73`,a=14+n%6,o=34+n%8,s=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
    <rect width="64" height="64" rx="32" fill="${r}"/>
    <circle cx="32" cy="28" r="18" fill="#e5eef0"/>
    <circle cx="25" cy="26" r="3.2" fill="${r}"/>
    <circle cx="39" cy="26" r="3.2" fill="${r}"/>
    <path d="M24 ${o} Q32 ${o+a/4} 40 ${o}" fill="none" stroke="${i}" stroke-width="2.4" stroke-linecap="round"/>
    <circle cx="48" cy="14" r="5" fill="${i}"/>
  </svg>`;return`data:image/svg+xml;charset=utf-8,${encodeURIComponent(s)}`}function n(e){return e.startsWith(`data:image/`)?e:``}function r(e,t){let r=n(e);return r.length>0?r:t}export{r as n,n as r,t};
//# sourceMappingURL=gaze-avatar-DPFKX6vb.js.map