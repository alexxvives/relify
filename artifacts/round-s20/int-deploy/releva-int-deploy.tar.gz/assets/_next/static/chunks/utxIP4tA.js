var e=[`alba`,`nube`,`cala`,`duna`,`bruma`,`olivo`,`roble`,`faro`];function t(e){let t=0;for(let n=0;n<e.length;n+=1)t=t*33+e.charCodeAt(n)>>>0;return t}function n(n){let r=n.replace(/[^a-zA-Z0-9]/g,``).slice(0,32)||`relify`;if(e.includes(r))return`/waitlist/${r}.svg`;let i=t(r),a=`#1c2740`,o=`#0f6e73`,s=14+i%6,c=34+i%8,l=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">
    <rect width="64" height="64" rx="32" fill="${a}"/>
    <circle cx="32" cy="28" r="18" fill="#e5eef0"/>
    <circle cx="25" cy="26" r="3.2" fill="${a}"/>
    <circle cx="39" cy="26" r="3.2" fill="${a}"/>
    <path d="M24 ${c} Q32 ${c+s/4} 40 ${c}" fill="none" stroke="${o}" stroke-width="2.4" stroke-linecap="round"/>
    <circle cx="48" cy="14" r="5" fill="${o}"/>
  </svg>`;return`data:image/svg+xml;charset=utf-8,${encodeURIComponent(l)}`}function r(e){return e.startsWith(`data:image/`)?e:``}function i(e,t){let n=r(e);return n.length>0?n:t}export{i as n,r,n as t};